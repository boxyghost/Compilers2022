
public class hello {
  public static int yo() {
    int i, x = 4;
  }
}
