#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "symtabentry.h"
#include "j0gram.tab.h"

struct sym_table * mksymtab() {
  struct sym_table * t = calloc(1, sizeof(struct sym_table));
  t->nEntries = 0;
  t->nBuckets = 5; // if change this change the line in symtabentry.h *tbl[x] where x matches this...
  //t->tbl = calloc(t->nBuckets, sizeof(struct sym_entry *) + t->nBuckets * sizeof(struct sym_entry));
  for (int i = 0; i < t->nBuckets; i++) {
    t->tbl[i] = calloc(1, sizeof(struct sym_entry));
    t->tbl[i]->s = "HEAD";
  }
  return t;
}

struct sym_entry * getnextentry(struct sym_table * table, int hash) {
  struct sym_entry * e = table->tbl[hash];
  while (e->next != NULL) {
    e = e->next;
  }
  return e;
}

void add_sym_entry(struct tree * t, struct sym_table * table) {
  if (t != NULL && t->leaf != NULL && t->leaf->text != NULL) {

    struct sym_entry * next_sym_entry = getnextentry(table, hash(table, t->leaf->text));

    if (t->leaf != NULL && t->leaf->category == IDENTIFIER && t->leaf->text != NULL) {
      next_sym_entry->next = calloc(1, sizeof(struct sym_entry));
      next_sym_entry = next_sym_entry->next;
      next_sym_entry->next = NULL;
      //printf("%s\n", t->leaf->text);
      next_sym_entry->s = calloc(128, sizeof(char));
      strncpy(next_sym_entry->s, t->leaf->text, 128);
      table->nEntries++;
    }
  }

  if (t == NULL) {
    return;
  }

  for (int i = 0; i < t->nkids; i++) {
      add_sym_entry(t->kids[i], table);
  }
}

void printtable(struct sym_table * table) {
  for (int i = 0; i < table->nBuckets; i++) {
    printf("\t\t Number: %d\n", i);
    struct sym_entry *e = table->tbl[i]->next; /*TODO fix this to be flexible*/
    while (e != NULL) {
      printf("\t%s\n", e->s);
      e = e->next;
    }
  }
}

int hash(SymbolTable st, char *s) {
   // return 0;
   register int h = 0;
   register char c;
   while ((c = *s++)) {
      h += c & 0377;
      h *= 37;
      }
   if (h < 0) h = -h;
   return h % st->nBuckets;
}
