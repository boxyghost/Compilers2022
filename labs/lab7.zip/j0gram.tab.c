/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.5.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "j0gram.y"

  #include <stdio.h>
  #include "tree.h"
  int yylex(void);
  int alctoken(int i);
  void yyerror(char const * h);

#line 78 "j0gram.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_J0GRAM_TAB_H_INCLUDED
# define YY_YY_J0GRAM_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    BREAK = 258,
    DOUBLE = 259,
    ELSE = 260,
    FOR = 261,
    IF = 262,
    INT = 263,
    RETURN = 264,
    VOID = 265,
    WHILE = 266,
    IDENTIFIER = 267,
    CLASSNAME = 268,
    CLASS = 269,
    STRING = 270,
    BOOL = 271,
    LINT = 272,
    LDOUBLE = 273,
    LSTRING = 274,
    LBOOL = 275,
    LCHAR = 276,
    NULLVAL = 277,
    LESSEQUAL = 278,
    GREATEREQUAL = 279,
    GREATER = 280,
    LESS = 281,
    EQUALEQUAL = 282,
    NOTEQUAL = 283,
    ANDAND = 284,
    OROR = 285,
    EQUAL = 286,
    ADDADD = 287,
    SUBSUB = 288,
    MULMUL = 289,
    DIVDIV = 290,
    MODMOD = 291,
    PUBLIC = 292,
    STATIC = 293,
    HEX = 294,
    OCT = 295,
    OPENCLOSE = 296,
    CASE = 297,
    CHAR = 298,
    CONTINUE = 299,
    DEFAULT = 300,
    FLOAT = 301,
    INSTANCEOF = 302,
    LONG = 303,
    NEW = 304,
    SWITCH = 305,
    ADDEQUAL = 306,
    SUBEQUAL = 307,
    INCREMENT = 308,
    DECREMENT = 309,
    ISEQUALTO = 310,
    NOTEQUALTO = 311,
    GREATHERTHANOREQUAL = 312,
    GREATERTHANOREQUAL = 313,
    LESSTHANOREQUAL = 314,
    LOGICALAND = 315,
    LOGICALOR = 316,
    CAST = 317,
    MULT = 318,
    DIVIDE = 319,
    MOD = 320
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 8 "j0gram.y"

  struct tree *treeptr;

#line 200 "j0gram.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_J0GRAM_TAB_H_INCLUDED  */



#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))

/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   709

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  85
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  77
/* YYNRULES -- Number of rules.  */
#define YYNRULES  178
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  300

#define YYUNDEFTOK  2
#define YYMAXUTOK   320


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    75,     2,     2,     2,    74,     2,     2,
      81,    82,    72,    70,    80,    71,    79,    73,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    67,    78,
      68,    66,    69,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    83,     2,    84,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    76,     2,    77,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint8 yyrline[] =
{
       0,    68,    68,    69,    69,    70,    70,    71,    71,    71,
      72,    73,    73,    73,    73,    73,    73,    73,    73,    75,
      75,    76,    76,    78,    78,    79,    81,    81,    82,    83,
      84,    84,    85,    85,    86,    87,    87,    88,    88,    89,
      91,    92,    93,    93,    95,    95,    96,    96,    97,    97,
      99,   100,   102,   102,   102,   102,   102,   103,   103,   103,
     104,   104,   104,   104,   106,   108,   108,   108,   108,   110,
     111,   112,   113,   115,   115,   116,   117,   119,   120,   120,
     120,   121,   121,   122,   122,   124,   124,   126,   126,   127,
     129,   129,   129,   129,   130,   130,   130,   130,   130,   130,
     130,   130,   132,   133,   133,   134,   136,   137,   138,   139,
     141,   141,   142,   142,   142,   143,   143,   144,   144,   145,
     145,   145,   146,   146,   146,   146,   147,   147,   149,   149,
     149,   150,   150,   151,   151,   153,   153,   153,   153,   153,
     153,   154,   155,   155,   155,   156,   156,   156,   156,   156,
     156,   158,   158,   158,   158,   160,   161,   161,   161,   162,
     162,   163,   165,   166,   167,   167,   167,   168,   168,   168,
     168,   168,   169,   171,   172,   173,   174,   174,   174
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "BREAK", "DOUBLE", "ELSE", "FOR", "IF",
  "INT", "RETURN", "VOID", "WHILE", "IDENTIFIER", "CLASSNAME", "CLASS",
  "STRING", "BOOL", "LINT", "LDOUBLE", "LSTRING", "LBOOL", "LCHAR",
  "NULLVAL", "LESSEQUAL", "GREATEREQUAL", "GREATER", "LESS", "EQUALEQUAL",
  "NOTEQUAL", "ANDAND", "OROR", "EQUAL", "ADDADD", "SUBSUB", "MULMUL",
  "DIVDIV", "MODMOD", "PUBLIC", "STATIC", "HEX", "OCT", "OPENCLOSE",
  "CASE", "CHAR", "CONTINUE", "DEFAULT", "FLOAT", "INSTANCEOF", "LONG",
  "NEW", "SWITCH", "ADDEQUAL", "SUBEQUAL", "INCREMENT", "DECREMENT",
  "ISEQUALTO", "NOTEQUALTO", "GREATHERTHANOREQUAL", "GREATERTHANOREQUAL",
  "LESSTHANOREQUAL", "LOGICALAND", "LOGICALOR", "CAST", "MULT", "DIVIDE",
  "MOD", "'='", "':'", "'<'", "'>'", "'+'", "'-'", "'*'", "'/'", "'%'",
  "'!'", "'{'", "'}'", "';'", "'.'", "','", "'('", "')'", "'['", "']'",
  "$accept", "ClassDecl", "ClassBody", "ClassBodyDecls", "ClassBodyDecl",
  "FieldDecl", "Type", "Name", "QualifiedName", "VarDecls",
  "VarDeclarator", "MethodReturnVal", "MethodDecl", "MethodHeader",
  "StaticStatus", "PublicStatus", "MethodDeclarator", "FormalParmListOpt",
  "FormalParmList", "FormalParm", "ConstructorDecl",
  "ConstructorDeclarator", "ArgListOpt", "Block", "BlockStmts",
  "BlockStmt", "LocalVarDeclStmt", "LocalVarDecl", "Stmt", "ExprStmt",
  "StmtExpr", "IfThenStmt", "IfThenElseStmt", "IfThenElseIfStmt",
  "ElseIfSequence", "ElseIfStmt", "WhileStmt", "ForStmt", "ForInit",
  "ExprOpt", "ForUpdate", "StmtExprList", "BreakStmt", "ReturnStmt",
  "Primary", "Literal", "InstantiationExpr", "ArgList", "FieldAccess",
  "MethodCall", "PostFixExpr", "UnaryExpr", "MulExpr", "AddExpr", "RelOp",
  "RelExpr", "EqExpr", "CondAndExpr", "CondOrExpr", "Expr", "Assignment",
  "LeftHandSide", "AssignOp", "SpecialName", "SwitchBlock", "CaseBlock",
  "CaseList", "CaseHead", "ArrayDec", "ArrayLeft", "ArrayRight",
  "LiteralList", "ArrayInit", "InstncExpr", "ObjectInt", "Cast", "NumBase", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_int16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,    61,    58,    60,    62,
      43,    45,    42,    47,    37,    33,   123,   125,    59,    46,
      44,    40,    41,    91,    93
};
# endif

#define YYPACT_NINF (-243)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-145)

#define yytable_value_is_error(Yyn) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      -8,    52,    72,    66,  -243,    23,     5,  -243,  -243,  -243,
       4,  -243,  -243,  -243,  -243,  -243,  -243,  -243,   107,  -243,
    -243,    69,   425,  -243,  -243,    26,    45,  -243,    26,  -243,
     649,  -243,  -243,  -243,   425,    17,  -243,  -243,  -243,  -243,
      81,   495,   308,  -243,  -243,   563,  -243,    69,    31,    38,
    -243,  -243,    69,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,   649,    69,   628,   628,   495,    69,   560,    41,
    -243,   300,  -243,  -243,  -243,    32,    46,     2,   114,   100,
     103,    51,  -243,   638,  -243,  -243,  -243,  -243,   -11,    62,
      70,   495,    78,    69,    82,  -243,  -243,     6,   544,  -243,
     356,  -243,  -243,    87,  -243,  -243,    92,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,    41,  -243,    93,  -243,    10,  -243,
    -243,    -3,  -243,  -243,   159,  -243,  -243,   649,  -243,    91,
      73,   425,   127,  -243,  -243,  -243,    94,   425,    69,   495,
     495,   163,   628,   628,   628,   628,   628,  -243,  -243,  -243,
    -243,   628,   628,   628,   628,   628,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,   495,    99,  -243,   543,   495,   101,  -243,
     495,   168,    69,    69,   440,    98,  -243,  -243,  -243,  -243,
     -14,  -243,  -243,   102,  -243,  -243,    15,   104,  -243,   425,
     105,   109,  -243,   108,     8,  -243,  -243,  -243,    32,    32,
      46,     2,     2,   114,   100,  -243,  -243,    69,  -243,  -243,
     113,   115,   111,  -243,   112,   495,   239,   425,   649,   661,
     649,  -243,  -243,  -243,   120,  -243,  -243,   495,  -243,   495,
     495,   495,   543,    26,   452,   117,   121,   122,   131,   612,
     125,  -243,  -243,   110,   133,   139,  -243,   180,     6,  -243,
    -243,   182,    15,  -243,   147,   150,  -243,  -243,  -243,   543,
       0,   226,  -243,    15,    35,   404,  -243,   152,  -243,  -243,
     156,   115,   153,  -243,  -243,     0,  -243,   176,   178,  -243,
     404,   247,  -243,   179,    26,   495,  -243,  -243,   452,   251,
     183,  -243,  -243,   185,  -243,   187,  -243,    26,  -243,  -243
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     1,     0,    33,     2,    12,    11,
      19,    14,    13,    32,    15,    16,    17,     4,    33,     5,
       7,     0,    18,    20,     8,     0,    31,     9,     0,    22,
      36,     3,     6,    19,    25,     0,    23,   153,   151,   152,
       0,     0,     0,    28,    30,     0,    40,     0,     0,    35,
      37,    10,     0,    21,    94,    95,    97,    96,    98,   101,
      99,   100,     0,     0,     0,     0,     0,     0,   111,   110,
      90,    92,    93,   114,   115,   119,   126,   128,   131,   133,
     135,     0,   136,     0,   137,   138,   140,   139,     0,     0,
       0,    82,     0,     0,     0,    45,    53,     0,   142,    52,
       0,    46,    48,     0,    49,    54,     0,    57,    58,    59,
      60,    61,    55,    56,     0,    67,    66,    65,    22,    62,
      63,     0,    27,    26,     0,    39,    41,     0,    24,     0,
       0,   175,   111,    92,   112,   113,     0,   143,     0,    43,
      43,     0,     0,     0,     0,     0,     0,   122,   123,   124,
     125,     0,     0,     0,     0,     0,   154,   146,   147,   148,
     149,   150,   145,     0,     0,    87,    80,     0,     0,    81,
       0,     0,     0,     0,   143,    51,    44,    47,    50,    64,
       0,   166,   162,     0,    29,    38,     0,     0,    91,   173,
       0,    42,   103,     0,   105,   116,   117,   118,   120,   121,
     127,   129,   130,   132,   134,   141,    88,     0,    79,    85,
       0,    78,     0,    89,     0,    43,     0,   163,     0,   171,
      36,   176,   177,   178,     0,   174,   107,     0,   106,    43,
      43,    82,     0,     0,     0,     0,     0,     0,   168,     0,
       0,   172,   104,     0,     0,     0,    86,    69,     0,    76,
     102,     0,     0,   167,     0,   169,    34,   109,   108,    84,
       0,    71,    73,     0,     0,     0,   159,     0,   165,   170,
       0,    83,     0,    70,    75,     0,    74,     0,     0,   155,
       0,     0,   160,     0,     0,     0,    72,   161,     0,     0,
       0,   164,    77,     0,   158,     0,   156,     0,   157,    69
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -243,  -243,  -243,  -243,   240,  -243,    -2,    -6,  -243,   248,
      27,  -243,  -243,  -243,  -243,  -243,  -243,    40,  -243,   143,
    -243,  -243,  -129,   -20,  -243,   171,  -243,   118,  -215,  -243,
    -163,  -238,  -243,  -243,  -243,    14,  -243,  -243,  -243,    42,
    -243,    20,  -243,  -243,   -36,  -205,  -243,  -243,   155,   -32,
    -243,   -34,    12,   130,  -243,     9,   134,   135,  -243,   -39,
       3,  -243,  -243,     7,  -243,  -243,    21,  -242,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -219
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     7,    18,    19,    20,    67,    68,    23,   175,
      36,   124,    24,    25,    45,    26,   184,    48,    49,    50,
      27,    28,   190,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   261,   262,   110,   111,   210,   168,
     270,   211,   112,   113,    69,    70,   115,   191,    71,    72,
      73,    74,    75,    76,   151,    77,    78,    79,    80,   192,
      82,    83,   163,    29,   119,   264,   265,   266,   120,   121,
     182,   239,    84,    85,    86,    87,   224
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      22,   164,    81,   209,    21,    43,   114,   272,    46,     8,
     116,   193,    22,     9,   238,    34,    21,    10,    33,   249,
      11,    12,   274,   282,    22,   147,   148,   136,    47,     1,
     134,   135,   221,   267,   255,   218,    98,   274,   282,    22,
      97,    34,    13,   123,   277,   117,    34,   173,    14,   118,
     281,    15,   169,    16,   222,   223,   130,   131,   132,   132,
     129,   137,   219,   180,   114,   289,     3,   165,   116,   246,
     149,   150,     4,   294,   125,   181,    42,   263,     5,   128,
     278,    33,    17,    44,   229,    30,   235,   171,   -68,   230,
     -68,   174,   -68,    53,    98,    51,   209,    52,    97,     6,
     243,   244,    42,   117,   142,   143,   144,   118,   195,   196,
     197,     8,   279,   126,    37,     9,   145,   146,   127,    10,
     141,    22,    11,    12,   205,    47,    38,    39,   212,   154,
     114,   214,   189,   155,   116,   156,   132,   132,   132,   132,
     132,   152,   153,   166,    13,   132,   132,   132,   132,   132,
      14,   167,    40,    15,   187,    16,    41,   198,   199,   170,
      98,   201,   202,   172,   207,   178,   216,   217,    37,   117,
     179,   183,   -93,   118,   186,   194,   188,   206,    52,   213,
      38,    39,   226,   220,    31,   260,   225,   257,   242,   227,
     228,   231,   169,   233,   234,   232,   114,   251,   114,   250,
     116,   174,   116,   139,   241,   252,    40,   256,   140,    37,
      41,   253,    22,   247,    22,   258,   237,   259,    47,   133,
     133,    38,    39,   114,   263,   268,    98,   116,    98,   114,
     269,   275,   248,   116,   285,   117,   283,   117,   284,   118,
     273,   118,   137,   287,   114,   288,   293,    40,   116,   215,
     290,    41,   114,    98,   295,   286,   116,   291,    32,    98,
     240,   296,   117,   248,   292,   298,   118,   297,   117,    35,
     185,   177,   118,   245,    98,   276,     0,   299,   248,   271,
      37,   200,    98,   117,   208,   280,   248,   118,   203,     0,
     204,   117,    38,    39,     0,   118,     0,   133,   133,   133,
     133,   133,     0,     0,     0,     0,   133,   133,   133,   133,
     133,    88,     8,     0,    89,    90,     9,    91,    40,    92,
      33,   236,    41,    11,    12,    54,    55,    56,    57,    58,
      59,     0,  -144,  -144,  -144,  -144,  -144,     0,     0,     0,
       0,     0,     0,     0,     0,    93,     0,    60,    61,     0,
       0,    14,     0,     0,    15,     0,    16,     0,    94,    88,
       8,     0,    89,    90,     9,    91,  -144,    92,    33,     0,
       0,    11,    12,    54,    55,    56,    57,    58,    59,     0,
       0,     0,     0,     0,    42,    95,    96,     0,     0,    66,
       0,     0,     0,    93,     0,    60,    61,     0,     0,    14,
       0,     0,    15,     0,    16,     0,    94,    88,     8,     0,
      89,    90,     9,    91,     0,    92,    33,     0,     0,    11,
      12,    54,    55,    56,    57,    58,    59,     0,     0,     0,
       0,     0,    42,   176,    96,     0,     0,    66,     0,     0,
       0,    93,     0,    60,    61,     0,   263,    14,     0,     0,
      15,     0,    16,     0,    94,    88,     8,     0,    89,    90,
       9,    91,     0,    92,    33,     0,    37,    11,    12,    54,
      55,    56,    57,    58,    59,     0,     0,     0,    38,    39,
      42,    37,    96,     0,     0,    66,     0,     0,     0,    93,
       0,    60,    61,    38,    39,    14,     0,     0,    15,     8,
      16,     0,    94,     9,    40,     0,     0,    33,    41,     0,
      11,    12,    54,    55,    56,    57,    58,    59,   -25,    40,
     -25,     0,     0,    41,     0,     0,     0,     0,    42,     0,
      96,     0,     0,    66,    60,    61,     0,     0,    14,     0,
       0,    15,     0,    16,    62,     0,     0,     8,     0,     0,
       0,     9,     0,     0,     0,    33,   -18,    63,    11,    12,
      54,    55,    56,    57,    58,    59,    64,     8,     0,     0,
      65,     9,   -18,   122,     0,    33,    66,     0,    11,    12,
      93,     0,    60,    61,     0,    37,    14,     0,     0,    15,
       0,    16,  -142,  -142,  -142,  -142,  -142,    38,    39,     0,
       0,    37,     0,     0,     0,     0,    14,   138,     0,    15,
       0,    16,     0,    38,    39,     0,     0,     0,     0,     0,
     139,     0,     0,    40,    66,   140,  -142,    41,     0,    54,
      55,    56,    57,    58,    59,     0,   139,     0,     0,    40,
      33,   140,     0,    41,     0,    54,    55,    56,    57,    58,
      59,    60,    61,     8,     0,     0,     0,     9,     0,     0,
       0,    33,     0,     0,    11,    12,     0,    60,    61,     0,
     157,   158,   159,   160,   161,     0,     0,     0,    54,    55,
      56,    57,    58,    59,     0,     0,     0,     0,     0,   254,
       0,     0,    14,     0,     0,    15,     0,    16,     0,    64,
      60,    61,     0,    65,   162,     0,     0,     0,     0,    66
};

static const yytype_int16 yycheck[] =
{
       6,    12,    41,   166,     6,    25,    42,     7,    28,     4,
      42,   140,    18,     8,   219,    21,    18,    12,    12,   234,
      15,    16,   260,   265,    30,    23,    24,    66,    30,    37,
      64,    65,    17,   252,   239,    49,    42,   275,   280,    45,
      42,    47,    37,    45,   263,    42,    52,    41,    43,    42,
     265,    46,    91,    48,    39,    40,    62,    63,    64,    65,
      62,    67,    76,    66,   100,   280,    14,    78,   100,   232,
      68,    69,     0,   288,    47,    78,    76,    42,    12,    52,
      45,    12,    77,    38,    76,    81,   215,    93,    78,    81,
      80,    97,    82,    12,   100,    78,   259,    80,   100,    76,
     229,   230,    76,   100,    72,    73,    74,   100,   142,   143,
     144,     4,    77,    82,    41,     8,    70,    71,    80,    12,
      79,   127,    15,    16,   163,   127,    53,    54,   167,    29,
     166,   170,   138,    30,   166,    84,   142,   143,   144,   145,
     146,    27,    28,    81,    37,   151,   152,   153,   154,   155,
      43,    81,    79,    46,    81,    48,    83,   145,   146,    81,
     166,   152,   153,    81,   166,    78,   172,   173,    41,   166,
      78,    12,    79,   166,    83,    12,    82,    78,    80,    78,
      53,    54,    77,    81,    77,     5,    82,    77,   227,    80,
      82,    78,   231,    82,    82,    80,   232,    76,   234,    82,
     232,   207,   234,    76,    84,    83,    79,    82,    81,    41,
      83,    80,   218,   233,   220,    82,   218,    78,   220,    64,
      65,    53,    54,   259,    42,    78,   232,   259,   234,   265,
      80,     5,   234,   265,    81,   232,    84,   234,    82,   232,
     260,   234,   248,    67,   280,    67,   285,    79,   280,    81,
       3,    83,   288,   259,     3,   275,   288,    78,    18,   265,
     220,    78,   259,   265,   284,    78,   259,    82,   265,    21,
     127,   100,   265,   231,   280,   261,    -1,   297,   280,   259,
      41,   151,   288,   280,   166,   264,   288,   280,   154,    -1,
     155,   288,    53,    54,    -1,   288,    -1,   142,   143,   144,
     145,   146,    -1,    -1,    -1,    -1,   151,   152,   153,   154,
     155,     3,     4,    -1,     6,     7,     8,     9,    79,    11,
      12,    82,    83,    15,    16,    17,    18,    19,    20,    21,
      22,    -1,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    37,    -1,    39,    40,    -1,
      -1,    43,    -1,    -1,    46,    -1,    48,    -1,    50,     3,
       4,    -1,     6,     7,     8,     9,    66,    11,    12,    -1,
      -1,    15,    16,    17,    18,    19,    20,    21,    22,    -1,
      -1,    -1,    -1,    -1,    76,    77,    78,    -1,    -1,    81,
      -1,    -1,    -1,    37,    -1,    39,    40,    -1,    -1,    43,
      -1,    -1,    46,    -1,    48,    -1,    50,     3,     4,    -1,
       6,     7,     8,     9,    -1,    11,    12,    -1,    -1,    15,
      16,    17,    18,    19,    20,    21,    22,    -1,    -1,    -1,
      -1,    -1,    76,    77,    78,    -1,    -1,    81,    -1,    -1,
      -1,    37,    -1,    39,    40,    -1,    42,    43,    -1,    -1,
      46,    -1,    48,    -1,    50,     3,     4,    -1,     6,     7,
       8,     9,    -1,    11,    12,    -1,    41,    15,    16,    17,
      18,    19,    20,    21,    22,    -1,    -1,    -1,    53,    54,
      76,    41,    78,    -1,    -1,    81,    -1,    -1,    -1,    37,
      -1,    39,    40,    53,    54,    43,    -1,    -1,    46,     4,
      48,    -1,    50,     8,    79,    -1,    -1,    12,    83,    -1,
      15,    16,    17,    18,    19,    20,    21,    22,    78,    79,
      80,    -1,    -1,    83,    -1,    -1,    -1,    -1,    76,    -1,
      78,    -1,    -1,    81,    39,    40,    -1,    -1,    43,    -1,
      -1,    46,    -1,    48,    49,    -1,    -1,     4,    -1,    -1,
      -1,     8,    -1,    -1,    -1,    12,    12,    62,    15,    16,
      17,    18,    19,    20,    21,    22,    71,     4,    -1,    -1,
      75,     8,    12,    10,    -1,    12,    81,    -1,    15,    16,
      37,    -1,    39,    40,    -1,    41,    43,    -1,    -1,    46,
      -1,    48,    32,    33,    34,    35,    36,    53,    54,    -1,
      -1,    41,    -1,    -1,    -1,    -1,    43,    47,    -1,    46,
      -1,    48,    -1,    53,    54,    -1,    -1,    -1,    -1,    -1,
      76,    -1,    -1,    79,    81,    81,    66,    83,    -1,    17,
      18,    19,    20,    21,    22,    -1,    76,    -1,    -1,    79,
      12,    81,    -1,    83,    -1,    17,    18,    19,    20,    21,
      22,    39,    40,     4,    -1,    -1,    -1,     8,    -1,    -1,
      -1,    12,    -1,    -1,    15,    16,    -1,    39,    40,    -1,
      32,    33,    34,    35,    36,    -1,    -1,    -1,    17,    18,
      19,    20,    21,    22,    -1,    -1,    -1,    -1,    -1,    77,
      -1,    -1,    43,    -1,    -1,    46,    -1,    48,    -1,    71,
      39,    40,    -1,    75,    66,    -1,    -1,    -1,    -1,    81
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    37,    86,    14,     0,    12,    76,    87,     4,     8,
      12,    15,    16,    37,    43,    46,    48,    77,    88,    89,
      90,    91,    92,    93,    97,    98,   100,   105,   106,   148,
      81,    77,    89,    12,    92,    94,    95,    41,    53,    54,
      79,    83,    76,   108,    38,    99,   108,    91,   102,   103,
     104,    78,    80,    12,    17,    18,    19,    20,    21,    22,
      39,    40,    49,    62,    71,    75,    81,    91,    92,   129,
     130,   133,   134,   135,   136,   137,   138,   140,   141,   142,
     143,   144,   145,   146,   157,   158,   159,   160,     3,     6,
       7,     9,    11,    37,    50,    77,    78,    91,    92,   108,
     109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
     121,   122,   127,   128,   129,   131,   134,   145,   148,   149,
     153,   154,    10,    91,    96,    95,    82,    80,    95,    91,
      92,    92,    92,   133,   136,   136,   144,    92,    47,    76,
      81,    79,    72,    73,    74,    70,    71,    23,    24,    68,
      69,   139,    27,    28,    29,    30,    84,    32,    33,    34,
      35,    36,    66,   147,    12,    78,    81,    81,   124,   144,
      81,    92,    81,    41,    92,    94,    77,   110,    78,    78,
      66,    78,   155,    12,   101,   104,    83,    81,    82,    92,
     107,   132,   144,   107,    12,   136,   136,   136,   137,   137,
     138,   140,   140,   141,   142,   144,    78,    91,   112,   115,
     123,   126,   144,    78,   144,    81,    92,    92,    49,    76,
      81,    17,    39,    40,   161,    82,    77,    80,    82,    76,
      81,    78,    80,    82,    82,   107,    82,    91,   130,   156,
     102,    84,   144,   107,   107,   124,   115,   108,    91,   113,
      82,    76,    83,    80,    77,   130,    82,    77,    82,    78,
       5,   119,   120,    42,   150,   151,   152,   161,    78,    80,
     125,   126,     7,   108,   116,     5,   120,   161,    45,    77,
     151,   113,   152,    84,    82,    81,   108,    67,    67,   113,
       3,    78,   108,   144,   113,     3,    78,    82,    78,   108
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    85,    86,    87,    87,    88,    88,    89,    89,    89,
      90,    91,    91,    91,    91,    91,    91,    91,    91,    92,
      92,    93,    93,    94,    94,    95,    96,    96,    97,    98,
      99,    99,   100,   100,   101,   102,   102,   103,   103,   104,
     105,   106,   107,   107,   108,   108,   109,   109,   110,   110,
     111,   112,   113,   113,   113,   113,   113,   113,   113,   113,
     113,   113,   113,   113,   114,   115,   115,   115,   115,   116,
     117,   118,   118,   119,   119,   120,   121,   122,   123,   123,
     123,   124,   124,   125,   125,   126,   126,   127,   127,   128,
     129,   129,   129,   129,   130,   130,   130,   130,   130,   130,
     130,   130,   131,   132,   132,   133,   134,   134,   134,   134,
     135,   135,   136,   136,   136,   137,   137,   137,   137,   138,
     138,   138,   139,   139,   139,   139,   140,   140,   141,   141,
     141,   142,   142,   143,   143,   144,   144,   144,   144,   144,
     144,   145,   146,   146,   146,   147,   147,   147,   147,   147,
     147,   148,   148,   148,   148,   149,   150,   150,   150,   151,
     151,   152,   153,   154,   155,   155,   155,   156,   156,   156,
     156,   156,   157,   158,   159,   160,   161,   161,   161
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     4,     3,     2,     1,     2,     1,     1,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     1,     1,     3,     1,     1,     1,     2,     4,
       1,     0,     1,     0,     4,     1,     0,     1,     3,     2,
       2,     4,     1,     0,     3,     2,     1,     2,     1,     1,
       2,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     1,     1,     1,     1,     5,
       7,     6,     8,     1,     2,     2,     5,     9,     1,     1,
       0,     1,     0,     1,     0,     1,     3,     2,     3,     3,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     5,     1,     3,     3,     4,     4,     6,     6,
       1,     1,     2,     2,     1,     1,     3,     3,     3,     1,
       3,     3,     1,     1,     1,     1,     1,     3,     1,     3,
       3,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     3,     1,     2,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     2,     4,     7,     4,     5,     4,     1,
       2,     3,     2,     3,     7,     5,     1,     2,     1,     2,
       3,     0,     5,     3,     4,     2,     1,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yytype], *yyvaluep);
# endif
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyo, yytype, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[+yyssp[yyi + 1 - yynrhs]],
                       &yyvsp[(yyi + 1) - (yynrhs)]
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
#  else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                yy_state_t *yyssp, int yytoken)
{
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Actual size of YYARG. */
  int yycount = 0;
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[+*yyssp];
      YYPTRDIFF_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
      yysize = yysize0;
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYPTRDIFF_T yysize1
                    = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
                    yysize = yysize1;
                  else
                    return 2;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    /* Don't count the "%s"s in the final size, but reserve room for
       the terminator.  */
    YYPTRDIFF_T yysize1 = yysize + (yystrlen (yyformat) - 2 * yycount) + 1;
    if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
      yysize = yysize1;
    else
      return 2;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss;
    yy_state_t *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYPTRDIFF_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
# undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2:
#line 68 "j0gram.y"
                                             {/*tree_print($3, 4);*/ (yyval.treeptr) = bingo((yyvsp[-3].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr)); }
#line 1695 "j0gram.tab.c"
    break;

  case 3:
#line 69 "j0gram.y"
                                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1001); }
#line 1701 "j0gram.tab.c"
    break;

  case 4:
#line 69 "j0gram.y"
                                                                               { (yyval.treeptr) = NULL;}
#line 1707 "j0gram.tab.c"
    break;

  case 5:
#line 70 "j0gram.y"
                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1002); }
#line 1713 "j0gram.tab.c"
    break;

  case 6:
#line 70 "j0gram.y"
                                                                                                 { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1003); }
#line 1719 "j0gram.tab.c"
    break;

  case 7:
#line 71 "j0gram.y"
                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1004); }
#line 1725 "j0gram.tab.c"
    break;

  case 8:
#line 71 "j0gram.y"
                                                                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1005); }
#line 1731 "j0gram.tab.c"
    break;

  case 9:
#line 71 "j0gram.y"
                                                                                                                                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1006); }
#line 1737 "j0gram.tab.c"
    break;

  case 10:
#line 72 "j0gram.y"
                             { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1007); }
#line 1743 "j0gram.tab.c"
    break;

  case 11:
#line 73 "j0gram.y"
           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1008); }
#line 1749 "j0gram.tab.c"
    break;

  case 12:
#line 73 "j0gram.y"
                                                        { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1009); }
#line 1755 "j0gram.tab.c"
    break;

  case 13:
#line 73 "j0gram.y"
                                                                                                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1010); }
#line 1761 "j0gram.tab.c"
    break;

  case 14:
#line 73 "j0gram.y"
                                                                                                                                                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1011); }
#line 1767 "j0gram.tab.c"
    break;

  case 15:
#line 73 "j0gram.y"
                                                                                                                                                                                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1012); }
#line 1773 "j0gram.tab.c"
    break;

  case 16:
#line 73 "j0gram.y"
                                                                                                                                                                                                                                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1013);}
#line 1779 "j0gram.tab.c"
    break;

  case 17:
#line 73 "j0gram.y"
                                                                                                                                                                                                                                                                               { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1014);}
#line 1785 "j0gram.tab.c"
    break;

  case 18:
#line 73 "j0gram.y"
                                                                                                                                                                                                                                                                                                                         { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1015); }
#line 1791 "j0gram.tab.c"
    break;

  case 19:
#line 75 "j0gram.y"
                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1016); }
#line 1797 "j0gram.tab.c"
    break;

  case 20:
#line 75 "j0gram.y"
                                                                    { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1017); /*todo maybe this is where I do ++ and [1], ect*/}
#line 1803 "j0gram.tab.c"
    break;

  case 21:
#line 76 "j0gram.y"
                                   { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1018); }
#line 1809 "j0gram.tab.c"
    break;

  case 22:
#line 76 "j0gram.y"
                                                                                        {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1019);}
#line 1815 "j0gram.tab.c"
    break;

  case 23:
#line 78 "j0gram.y"
                        { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1020); }
#line 1821 "j0gram.tab.c"
    break;

  case 24:
#line 78 "j0gram.y"
                                                                                        { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1021); }
#line 1827 "j0gram.tab.c"
    break;

  case 25:
#line 79 "j0gram.y"
                    { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1022); }
#line 1833 "j0gram.tab.c"
    break;

  case 26:
#line 81 "j0gram.y"
                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1023); }
#line 1839 "j0gram.tab.c"
    break;

  case 27:
#line 81 "j0gram.y"
                                                                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1024); }
#line 1845 "j0gram.tab.c"
    break;

  case 28:
#line 82 "j0gram.y"
                               { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1025); }
#line 1851 "j0gram.tab.c"
    break;

  case 29:
#line 83 "j0gram.y"
                                                                         { (yyval.treeptr) = alcTreeFourKids((yyvsp[-3].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1026); }
#line 1857 "j0gram.tab.c"
    break;

  case 30:
#line 84 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1157); }
#line 1863 "j0gram.tab.c"
    break;

  case 31:
#line 84 "j0gram.y"
                                                          {(yyval.treeptr) = NULL;}
#line 1869 "j0gram.tab.c"
    break;

  case 32:
#line 85 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1160); }
#line 1875 "j0gram.tab.c"
    break;

  case 33:
#line 85 "j0gram.y"
                                                          {(yyval.treeptr) = NULL;}
#line 1881 "j0gram.tab.c"
    break;

  case 34:
#line 86 "j0gram.y"
                                                       { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1027); }
#line 1887 "j0gram.tab.c"
    break;

  case 35:
#line 87 "j0gram.y"
                                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1028); }
#line 1893 "j0gram.tab.c"
    break;

  case 36:
#line 87 "j0gram.y"
                                                                      {(yyval.treeptr) = NULL;}
#line 1899 "j0gram.tab.c"
    break;

  case 37:
#line 88 "j0gram.y"
                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1029); }
#line 1905 "j0gram.tab.c"
    break;

  case 38:
#line 88 "j0gram.y"
                                                                                             { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1030); }
#line 1911 "j0gram.tab.c"
    break;

  case 39:
#line 89 "j0gram.y"
                               { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1031); }
#line 1917 "j0gram.tab.c"
    break;

  case 40:
#line 91 "j0gram.y"
                                             { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1032); }
#line 1923 "j0gram.tab.c"
    break;

  case 41:
#line 92 "j0gram.y"
                                                            { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1033); }
#line 1929 "j0gram.tab.c"
    break;

  case 42:
#line 93 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1034); }
#line 1935 "j0gram.tab.c"
    break;

  case 43:
#line 93 "j0gram.y"
                                                          {(yyval.treeptr) = NULL;}
#line 1941 "j0gram.tab.c"
    break;

  case 44:
#line 95 "j0gram.y"
                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1035); }
#line 1947 "j0gram.tab.c"
    break;

  case 45:
#line 95 "j0gram.y"
                                                                      {(yyval.treeptr) = NULL;}
#line 1953 "j0gram.tab.c"
    break;

  case 46:
#line 96 "j0gram.y"
                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1036); }
#line 1959 "j0gram.tab.c"
    break;

  case 47:
#line 96 "j0gram.y"
                                                                                { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1037); }
#line 1965 "j0gram.tab.c"
    break;

  case 48:
#line 97 "j0gram.y"
                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1038); }
#line 1971 "j0gram.tab.c"
    break;

  case 49:
#line 97 "j0gram.y"
                                                                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1039); }
#line 1977 "j0gram.tab.c"
    break;

  case 50:
#line 99 "j0gram.y"
                                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1040); }
#line 1983 "j0gram.tab.c"
    break;

  case 51:
#line 100 "j0gram.y"
                            { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1041); /*TODO make sure we can do "int i = 0;" here, ect*/}
#line 1989 "j0gram.tab.c"
    break;

  case 52:
#line 102 "j0gram.y"
            { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1043); }
#line 1995 "j0gram.tab.c"
    break;

  case 53:
#line 102 "j0gram.y"
                                                    {(yyval.treeptr) = NULL;}
#line 2001 "j0gram.tab.c"
    break;

  case 54:
#line 102 "j0gram.y"
                                                                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1044); }
#line 2007 "j0gram.tab.c"
    break;

  case 55:
#line 102 "j0gram.y"
                                                                                                                         { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1045); }
#line 2013 "j0gram.tab.c"
    break;

  case 56:
#line 102 "j0gram.y"
                                                                                                                                                                        { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1046); }
#line 2019 "j0gram.tab.c"
    break;

  case 57:
#line 103 "j0gram.y"
                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1047); }
#line 2025 "j0gram.tab.c"
    break;

  case 58:
#line 103 "j0gram.y"
                                                                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1048); }
#line 2031 "j0gram.tab.c"
    break;

  case 59:
#line 103 "j0gram.y"
                                                                                                                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1049); }
#line 2037 "j0gram.tab.c"
    break;

  case 60:
#line 104 "j0gram.y"
                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1050); }
#line 2043 "j0gram.tab.c"
    break;

  case 61:
#line 104 "j0gram.y"
                                                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1051);}
#line 2049 "j0gram.tab.c"
    break;

  case 62:
#line 104 "j0gram.y"
                                                                                                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1052);}
#line 2055 "j0gram.tab.c"
    break;

  case 63:
#line 104 "j0gram.y"
                                                                                                                                                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1053);}
#line 2061 "j0gram.tab.c"
    break;

  case 64:
#line 106 "j0gram.y"
                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1054); }
#line 2067 "j0gram.tab.c"
    break;

  case 65:
#line 108 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1055); }
#line 2073 "j0gram.tab.c"
    break;

  case 66:
#line 108 "j0gram.y"
                                                                    { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1056); }
#line 2079 "j0gram.tab.c"
    break;

  case 67:
#line 108 "j0gram.y"
                                                                                                                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1057); }
#line 2085 "j0gram.tab.c"
    break;

  case 68:
#line 108 "j0gram.y"
                                                                                                                                                                           {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1058);}
#line 2091 "j0gram.tab.c"
    break;

  case 69:
#line 110 "j0gram.y"
                                  { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-4].treeptr), (yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1059); }
#line 2097 "j0gram.tab.c"
    break;

  case 70:
#line 111 "j0gram.y"
                                                 { (yyval.treeptr) = alcTreeFiveKids((yyvsp[-6].treeptr), (yyvsp[-4].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1060); }
#line 2103 "j0gram.tab.c"
    break;

  case 71:
#line 112 "j0gram.y"
                                                       { (yyval.treeptr) = alcTreeFourKids((yyvsp[-5].treeptr), (yyvsp[-3].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1061); }
#line 2109 "j0gram.tab.c"
    break;

  case 72:
#line 113 "j0gram.y"
                                                          { (yyval.treeptr) = alcTreeSixKids((yyvsp[-7].treeptr), (yyvsp[-5].treeptr), (yyvsp[-3].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1062); }
#line 2115 "j0gram.tab.c"
    break;

  case 73:
#line 115 "j0gram.y"
                           { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1063); }
#line 2121 "j0gram.tab.c"
    break;

  case 74:
#line 115 "j0gram.y"
                                                                                         { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1064); }
#line 2127 "j0gram.tab.c"
    break;

  case 75:
#line 116 "j0gram.y"
                            { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1065); }
#line 2133 "j0gram.tab.c"
    break;

  case 76:
#line 117 "j0gram.y"
                                   { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-4].treeptr), (yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1066); }
#line 2139 "j0gram.tab.c"
    break;

  case 77:
#line 119 "j0gram.y"
                                                             {(yyval.treeptr) = alcTreeFiveKids((yyvsp[-8].treeptr), (yyvsp[-6].treeptr), (yyvsp[-4].treeptr), (yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1067); }
#line 2145 "j0gram.tab.c"
    break;

  case 78:
#line 120 "j0gram.y"
                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1068); }
#line 2151 "j0gram.tab.c"
    break;

  case 79:
#line 120 "j0gram.y"
                                                                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1069); }
#line 2157 "j0gram.tab.c"
    break;

  case 80:
#line 120 "j0gram.y"
                                                                                                           {(yyval.treeptr) = NULL;}
#line 2163 "j0gram.tab.c"
    break;

  case 81:
#line 121 "j0gram.y"
              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1070); }
#line 2169 "j0gram.tab.c"
    break;

  case 82:
#line 121 "j0gram.y"
                                                  {(yyval.treeptr) = NULL;}
#line 2175 "j0gram.tab.c"
    break;

  case 83:
#line 122 "j0gram.y"
                        { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1071); }
#line 2181 "j0gram.tab.c"
    break;

  case 84:
#line 122 "j0gram.y"
                                                            {(yyval.treeptr) = NULL;}
#line 2187 "j0gram.tab.c"
    break;

  case 85:
#line 124 "j0gram.y"
                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1072); }
#line 2193 "j0gram.tab.c"
    break;

  case 86:
#line 124 "j0gram.y"
                                                                                     { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1073); }
#line 2199 "j0gram.tab.c"
    break;

  case 87:
#line 126 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1074); }
#line 2205 "j0gram.tab.c"
    break;

  case 88:
#line 126 "j0gram.y"
                                                                              { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1075); }
#line 2211 "j0gram.tab.c"
    break;

  case 89:
#line 127 "j0gram.y"
                               { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1076); }
#line 2217 "j0gram.tab.c"
    break;

  case 90:
#line 129 "j0gram.y"
                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1077); }
#line 2223 "j0gram.tab.c"
    break;

  case 91:
#line 129 "j0gram.y"
                                                                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1078); }
#line 2229 "j0gram.tab.c"
    break;

  case 92:
#line 129 "j0gram.y"
                                                                                                                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1079); }
#line 2235 "j0gram.tab.c"
    break;

  case 93:
#line 129 "j0gram.y"
                                                                                                                                                                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1080); }
#line 2241 "j0gram.tab.c"
    break;

  case 102:
#line 132 "j0gram.y"
                                                  { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-4].treeptr), (yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1081); }
#line 2247 "j0gram.tab.c"
    break;

  case 103:
#line 133 "j0gram.y"
              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1082); }
#line 2253 "j0gram.tab.c"
    break;

  case 104:
#line 133 "j0gram.y"
                                                                   { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1083); }
#line 2259 "j0gram.tab.c"
    break;

  case 105:
#line 134 "j0gram.y"
                                    { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[0].treeptr), 1084); }
#line 2265 "j0gram.tab.c"
    break;

  case 106:
#line 136 "j0gram.y"
                                    { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1085); }
#line 2271 "j0gram.tab.c"
    break;

  case 107:
#line 137 "j0gram.y"
                                  { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1086); }
#line 2277 "j0gram.tab.c"
    break;

  case 108:
#line 138 "j0gram.y"
                                                    { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-5].treeptr), (yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1087); }
#line 2283 "j0gram.tab.c"
    break;

  case 109:
#line 139 "j0gram.y"
                                                    { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-5].treeptr), (yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1088); }
#line 2289 "j0gram.tab.c"
    break;

  case 110:
#line 141 "j0gram.y"
                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1089); }
#line 2295 "j0gram.tab.c"
    break;

  case 111:
#line 141 "j0gram.y"
                                                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1090); }
#line 2301 "j0gram.tab.c"
    break;

  case 112:
#line 142 "j0gram.y"
                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1091); /* TODO make this work lol */}
#line 2307 "j0gram.tab.c"
    break;

  case 113:
#line 142 "j0gram.y"
                                                                                                         { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1092); /* TODO make this work lol */}
#line 2313 "j0gram.tab.c"
    break;

  case 114:
#line 142 "j0gram.y"
                                                                                                                                                                                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1093); }
#line 2319 "j0gram.tab.c"
    break;

  case 115:
#line 143 "j0gram.y"
                   { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1094); }
#line 2325 "j0gram.tab.c"
    break;

  case 116:
#line 143 "j0gram.y"
                                                                             { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), kido(MULT), (yyvsp[0].treeptr), 1095); /* TODO make this work and below*/}
#line 2331 "j0gram.tab.c"
    break;

  case 117:
#line 144 "j0gram.y"
                            { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), kido(DIVIDE), (yyvsp[0].treeptr), 1096); }
#line 2337 "j0gram.tab.c"
    break;

  case 118:
#line 144 "j0gram.y"
                                                                                                          { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), kido(MOD), (yyvsp[0].treeptr), 1097); }
#line 2343 "j0gram.tab.c"
    break;

  case 119:
#line 145 "j0gram.y"
                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1098); }
#line 2349 "j0gram.tab.c"
    break;

  case 120:
#line 145 "j0gram.y"
                                                                         { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), kido('+'), (yyvsp[0].treeptr), 1099); }
#line 2355 "j0gram.tab.c"
    break;

  case 121:
#line 145 "j0gram.y"
                                                                                                                                                  { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), kido(SUBSUB), (yyvsp[0].treeptr), 1101); }
#line 2361 "j0gram.tab.c"
    break;

  case 122:
#line 146 "j0gram.y"
                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1102); }
#line 2367 "j0gram.tab.c"
    break;

  case 123:
#line 146 "j0gram.y"
                                                                  { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1103); }
#line 2373 "j0gram.tab.c"
    break;

  case 124:
#line 146 "j0gram.y"
                                                                                                          { (yyval.treeptr) = alcTreeOneKids(kido(LESS), 1104); }
#line 2379 "j0gram.tab.c"
    break;

  case 125:
#line 146 "j0gram.y"
                                                                                                                                                          { (yyval.treeptr) = alcTreeOneKids(kido(GREATER), 1105); /* TODO this too*/}
#line 2385 "j0gram.tab.c"
    break;

  case 126:
#line 147 "j0gram.y"
                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1106); }
#line 2391 "j0gram.tab.c"
    break;

  case 127:
#line 147 "j0gram.y"
                                                                           { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1107); }
#line 2397 "j0gram.tab.c"
    break;

  case 128:
#line 149 "j0gram.y"
                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1108); }
#line 2403 "j0gram.tab.c"
    break;

  case 129:
#line 149 "j0gram.y"
                                                                              { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1109); }
#line 2409 "j0gram.tab.c"
    break;

  case 130:
#line 149 "j0gram.y"
                                                                                                                                                    { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1110); }
#line 2415 "j0gram.tab.c"
    break;

  case 131:
#line 150 "j0gram.y"
                    { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1111); }
#line 2421 "j0gram.tab.c"
    break;

  case 132:
#line 150 "j0gram.y"
                                                                                  { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1112); }
#line 2427 "j0gram.tab.c"
    break;

  case 133:
#line 151 "j0gram.y"
                        { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1113); }
#line 2433 "j0gram.tab.c"
    break;

  case 134:
#line 151 "j0gram.y"
                                                                                        { (yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1114); }
#line 2439 "j0gram.tab.c"
    break;

  case 135:
#line 153 "j0gram.y"
                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1115); }
#line 2445 "j0gram.tab.c"
    break;

  case 136:
#line 153 "j0gram.y"
                                                                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1116);}
#line 2451 "j0gram.tab.c"
    break;

  case 137:
#line 153 "j0gram.y"
                                                                                                              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1117);}
#line 2457 "j0gram.tab.c"
    break;

  case 138:
#line 153 "j0gram.y"
                                                                                                                                                             {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1118);}
#line 2463 "j0gram.tab.c"
    break;

  case 139:
#line 153 "j0gram.y"
                                                                                                                                                                                                     {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1119);}
#line 2469 "j0gram.tab.c"
    break;

  case 140:
#line 153 "j0gram.y"
                                                                                                                                                                                                                                                  {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1159);}
#line 2475 "j0gram.tab.c"
    break;

  case 141:
#line 154 "j0gram.y"
                                       {(yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1120); }
#line 2481 "j0gram.tab.c"
    break;

  case 142:
#line 155 "j0gram.y"
                   {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1121); }
#line 2487 "j0gram.tab.c"
    break;

  case 143:
#line 155 "j0gram.y"
                                                                 {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1122); }
#line 2493 "j0gram.tab.c"
    break;

  case 144:
#line 155 "j0gram.y"
                                                                                                                     { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1123); }
#line 2499 "j0gram.tab.c"
    break;

  case 145:
#line 156 "j0gram.y"
              {(yyval.treeptr) = alcTreeOneKids(kido(EQUAL), 1124); }
#line 2505 "j0gram.tab.c"
    break;

  case 146:
#line 156 "j0gram.y"
                                                                 { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1125); }
#line 2511 "j0gram.tab.c"
    break;

  case 147:
#line 156 "j0gram.y"
                                                                                                            { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1126);}
#line 2517 "j0gram.tab.c"
    break;

  case 148:
#line 156 "j0gram.y"
                                                                                                                                                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1127);}
#line 2523 "j0gram.tab.c"
    break;

  case 149:
#line 156 "j0gram.y"
                                                                                                                                                                                                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1128);}
#line 2529 "j0gram.tab.c"
    break;

  case 150:
#line 156 "j0gram.y"
                                                                                                                                                                                                                                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1129); }
#line 2535 "j0gram.tab.c"
    break;

  case 151:
#line 158 "j0gram.y"
                            {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1130); }
#line 2541 "j0gram.tab.c"
    break;

  case 152:
#line 158 "j0gram.y"
                                                                                   {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1131); }
#line 2547 "j0gram.tab.c"
    break;

  case 153:
#line 158 "j0gram.y"
                                                                                                                                          {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1132); }
#line 2553 "j0gram.tab.c"
    break;

  case 154:
#line 158 "j0gram.y"
                                                                                                                                                                                                    {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1133); }
#line 2559 "j0gram.tab.c"
    break;

  case 155:
#line 160 "j0gram.y"
                                                   {  (yyval.treeptr) =  alcTreeThreeKids((yyvsp[-6].treeptr), (yyvsp[-4].treeptr), (yyvsp[-1].treeptr), 1134); }
#line 2565 "j0gram.tab.c"
    break;

  case 156:
#line 161 "j0gram.y"
                                   {(yyval.treeptr) = alcTreeThreeKids((yyvsp[-3].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1135);}
#line 2571 "j0gram.tab.c"
    break;

  case 157:
#line 161 "j0gram.y"
                                                                                                                  {(yyval.treeptr) = alcTreeFourKids((yyvsp[-4].treeptr), (yyvsp[-3].treeptr), (yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1136);}
#line 2577 "j0gram.tab.c"
    break;

  case 158:
#line 161 "j0gram.y"
                                                                                                                                                                                             {(yyval.treeptr) = alcTreeOneKids((yyvsp[-3].treeptr), 1137);}
#line 2583 "j0gram.tab.c"
    break;

  case 159:
#line 162 "j0gram.y"
                   {(yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1138); }
#line 2589 "j0gram.tab.c"
    break;

  case 160:
#line 162 "j0gram.y"
                                                                         {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1139); }
#line 2595 "j0gram.tab.c"
    break;

  case 161:
#line 163 "j0gram.y"
                           {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1140); }
#line 2601 "j0gram.tab.c"
    break;

  case 162:
#line 165 "j0gram.y"
                               { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1141); }
#line 2607 "j0gram.tab.c"
    break;

  case 163:
#line 166 "j0gram.y"
                               {(yyval.treeptr) = alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1142); }
#line 2613 "j0gram.tab.c"
    break;

  case 164:
#line 167 "j0gram.y"
                                              {  (yyval.treeptr) =  alcTreeThreeKids((yyvsp[-5].treeptr), (yyvsp[-4].treeptr), (yyvsp[-2].treeptr), 1143); }
#line 2619 "j0gram.tab.c"
    break;

  case 165:
#line 167 "j0gram.y"
                                                                                                                          { (yyval.treeptr) = alcTreeOneKids((yyvsp[-2].treeptr), 1144); }
#line 2625 "j0gram.tab.c"
    break;

  case 166:
#line 167 "j0gram.y"
                                                                                                                                                                   {(yyval.treeptr) = NULL;}
#line 2631 "j0gram.tab.c"
    break;

  case 167:
#line 168 "j0gram.y"
                         { (yyval.treeptr) = alcTreeOneKids((yyvsp[-1].treeptr), 1145); }
#line 2637 "j0gram.tab.c"
    break;

  case 168:
#line 168 "j0gram.y"
                                                                      { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1146); }
#line 2643 "j0gram.tab.c"
    break;

  case 169:
#line 168 "j0gram.y"
                                                                                                                               {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1147); }
#line 2649 "j0gram.tab.c"
    break;

  case 170:
#line 168 "j0gram.y"
                                                                                                                                                                                               {(yyval.treeptr) = alcTreeTwoKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), 1148); }
#line 2655 "j0gram.tab.c"
    break;

  case 171:
#line 168 "j0gram.y"
                                                                                                                                                                                                                                       {(yyval.treeptr) = NULL;}
#line 2661 "j0gram.tab.c"
    break;

  case 172:
#line 169 "j0gram.y"
                                    {  (yyval.treeptr) =  alcTreeThreeKids((yyvsp[-4].treeptr), (yyvsp[-3].treeptr), (yyvsp[-1].treeptr), 1149); }
#line 2667 "j0gram.tab.c"
    break;

  case 173:
#line 171 "j0gram.y"
                                 {(yyval.treeptr) =  alcTreeThreeKids((yyvsp[-2].treeptr), (yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1150);}
#line 2673 "j0gram.tab.c"
    break;

  case 174:
#line 172 "j0gram.y"
                            { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-3].treeptr), (yyvsp[-2].treeptr), 1158); }
#line 2679 "j0gram.tab.c"
    break;

  case 175:
#line 173 "j0gram.y"
                { (yyval.treeptr) = alcTreeTwoKids((yyvsp[-1].treeptr), (yyvsp[0].treeptr), 1151); }
#line 2685 "j0gram.tab.c"
    break;

  case 176:
#line 174 "j0gram.y"
              { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1152); }
#line 2691 "j0gram.tab.c"
    break;

  case 177:
#line 174 "j0gram.y"
                                                       { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1153); }
#line 2697 "j0gram.tab.c"
    break;

  case 178:
#line 174 "j0gram.y"
                                                                                                { (yyval.treeptr) = alcTreeOneKids((yyvsp[0].treeptr), 1154); }
#line 2703 "j0gram.tab.c"
    break;


#line 2707 "j0gram.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *, YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif


/*-----------------------------------------------------.
| yyreturn -- parsing is finished, return the result.  |
`-----------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[+*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 176 "j0gram.y"


const char *yyname(int sym) {
return yytname[sym - BREAK + 3];
}
