public class everything {
	public static void main(String argv[]) {
   		// char letter1;
		// short short1; // probly dont need this
		int int1;
		long long1;
		float float1;
		double double1;
		String str1;
		// char letter2 = 'a';
		// short short2 = 32767; not needed -- should cause compilation crash.
		int int2 = 3;
		long long2 = 9223372036854775807;
		float float2 = 3.33;
		double double2 = 1.000003;
		// String str2 = "Thisisa\tstring\n";
		// letter1 = 'b';
		short1 = -32768;
		int1 = 2147483647;
		long1 = -9223372036854775808;
		float1 = 35e3;
		double1 = 12E4;
		// str1;
		int2++;
		int1--;
		int1 -= int2;
		int2 += 4;
		String escapes = "yo";
		//Arrays of stuff
		int array1[];
		// array1 = new int[10];

		// String array2[] = {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"};



		//Control sequences and Operators
		if(x == y){

		} else {

		}

		if (x != y) {

		} else if(x>y){

		} else {

		}

		if (x>y) {

		} else if(x>=y){

		} else if(x<=y){

		} else if(x && y){

		} else if(x || y){

		} else if( !x){

		} else {

		}

		int c = 0;
		// switch(c){
		// 	case 1:
		// 		System.out.println("case 1"); break;
		// 	case 2:
		// 		System.out.println("case 2"); break;
		// 	case 3:
		// 		System.out.println("case 3"); break;
		// 	case 4:
		// 		System.out.println("case 4"); break;
		// 	default:
		// 		System.out.println("default"); break;
		// }

		while(int2 > 0){
			int2--;
		}

		for(int i = 1; i <= 100; i++){
			//Fizzbuzz should be in here
		}
		//This is a single line comment
      	System.out.println();

   	}
}
