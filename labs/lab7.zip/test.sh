make
./j0 john_test.java
./j0 everything.java
