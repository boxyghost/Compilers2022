#include "tree.h"
typedef struct sym_entry {
    /*   SymbolTable table;			 what symbol table do we belong to*/
    char *s;				/* string */
    /* more symbol attributes go here for code generation */
    struct sym_entry *next;
 } *SymbolTableEntry;

 typedef struct sym_table {
    int nEntries;			/* # of symbols in the table */
    int nBuckets;
    /*   struct sym_table *parent;		 enclosing scope, superclass etc. */
    struct sym_entry *tbl[5]; //this changes with the number of buckets in mksymtab()
    /* more per-scope/per-symbol-table attributes go here */
} *SymbolTable;

struct sym_table * mksymtab();
void add_sym_entry(struct tree *, struct sym_table *);
void printtable(struct sym_table *);
int hash(SymbolTable st, char *s);
