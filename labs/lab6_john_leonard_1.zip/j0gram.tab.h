/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_J0GRAM_TAB_H_INCLUDED
# define YY_YY_J0GRAM_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    BREAK = 258,
    DOUBLE = 259,
    ELSE = 260,
    FOR = 261,
    IF = 262,
    INT = 263,
    RETURN = 264,
    VOID = 265,
    WHILE = 266,
    IDENTIFIER = 267,
    CLASSNAME = 268,
    CLASS = 269,
    STRING = 270,
    BOOL = 271,
    LINT = 272,
    LDOUBLE = 273,
    LSTRING = 274,
    LBOOL = 275,
    LCHAR = 276,
    NULLVAL = 277,
    LESSEQUAL = 278,
    GREATEREQUAL = 279,
    GREATER = 280,
    LESS = 281,
    EQUALEQUAL = 282,
    NOTEQUAL = 283,
    ANDAND = 284,
    OROR = 285,
    EQUAL = 286,
    ADDADD = 287,
    SUBSUB = 288,
    MULMUL = 289,
    DIVDIV = 290,
    MODMOD = 291,
    PUBLIC = 292,
    STATIC = 293,
    HEX = 294,
    OCT = 295,
    OPENCLOSE = 296,
    CASE = 297,
    CHAR = 298,
    CONTINUE = 299,
    DEFAULT = 300,
    FLOAT = 301,
    INSTANCEOF = 302,
    LONG = 303,
    NEW = 304,
    SWITCH = 305,
    ADDEQUAL = 306,
    SUBEQUAL = 307,
    INCREMENT = 308,
    DECREMENT = 309,
    ISEQUALTO = 310,
    NOTEQUALTO = 311,
    GREATHERTHANOREQUAL = 312,
    GREATERTHANOREQUAL = 313,
    LESSTHANOREQUAL = 314,
    LOGICALAND = 315,
    LOGICALOR = 316,
    CAST = 317,
    MULT = 318,
    DIVIDE = 319,
    MOD = 320
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 8 "j0gram.y"

  struct tree *treeptr;

#line 127 "j0gram.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_J0GRAM_TAB_H_INCLUDED  */
