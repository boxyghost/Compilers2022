
public class hello {
  public static int yo() {
    bingo();
    for (; ; ) {

    }
  }
  public static int helo(){}
  public static void helloWorld(int x, int y) {
    int i;
    i = 0;
    int x = 0;
    //for()
    /*






    */
    //for()
    for(int x = 3; i==0; i++) {
      //for()
      i = 2;
      i++;
    }
    if(x == 3) {};
    if(x != 3) {};
    if(x <= 3) {};
    if(x[4] >= 3) {};
    if(i > 3) {
      yo();
    } else if (x < 5){
      yip(3, 5); // todo skip for now
      char x = 'x';
      x = 'x';/*

      */
      float x = 3.5;
      // short x = 3; // might not need to do this lol
      x = 3.5;
      boolean b = true;
      String s = "abcd";
      double d = 4.5;
      d = 6.754;
      x++;
      x--;
      x = x--;
      x *= 4; // might not have to do these?
      x /= 4; // might not have to do these?
      x %= 4; // might not have to do these?
      x += 3;
    } else {
      print("hotdog");
    }
    while(x > 3) {}

    switch ( c ){
        case 1: case 2:
            System.out.println("1 or 2\n"); break;
        case 3: case 4:
            System.out.println("3 or 4\n"); break;
        default:
            System.out.println("some other value\n");
    }
    int[] x;
    x = new int[5];
    int[] w = new int[8];

    int[] y = {};
    int[] z = {4, 5, 6};
    int[] u = {1};
    x = x[3] + 5;
    x[5] = 4;
    //Note to self: TODO: there should be more array tests too.
    /* multi line
    comment plz

    */

    while (x < 2) {
      yo();
      break;
    }
    x++; // todo add this
    for (int x = 3; x < 3; x = x + 1) {
      yup();
      break;
    }
    x = x + 3 - 5 + 3 * y / 3 % 4;
    x += 3;
    y -= 4;
    y = -4;
    y = x - 4;

    if (x < 3 || y < 3) {
      yo();
    }
    if (x < 3 && y < 3) {
      yo();
    }
    if (x instanceof y) {

    }
    x[4] = 3;
    x.y = 3;
    x = (int) hotdog;
    x = 0xaa;
    x = 0123;
    x = 4l;
    return 4;
  }

}
