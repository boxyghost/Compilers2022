public class hello {
  public static void helloWorld() {
    int i;
    i = 0;
    int x = 0;
    for(int x; i>0; i = i+1) {
      i = 2;
    }
  }

}
